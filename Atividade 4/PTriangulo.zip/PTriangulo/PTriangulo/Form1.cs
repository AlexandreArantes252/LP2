﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double a, b, c;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtTipoTriangulo.Text = "";

            txtLadoA.Focus();
        }
        private void btnTriangulo_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtLadoA.Text, out a) && Double.TryParse(txtLadoB.Text, out b) && Double.TryParse(txtLadoC.Text, out c))
            {
                if (Math.Abs(b - c) < a && a < b + c && Math.Abs(a - c) < b && b < a + c && Math.Abs(a - b) < c && c < a + b)
                {
                    if (a == b && b == c && a == c)
                        txtTipoTriangulo.Text = "Isto é um tirângulo Equilátero";
                    else if (a == b || a == c )
                        txtTipoTriangulo.Text = "Isto é um triângulo Isósceles";
                    else
                        txtTipoTriangulo.Text = "Isto é um triângulo Escaleno";
                }
                else
                    MessageBox.Show("Os valores inseridos não pertencem a um triângulo");
            }
            else
                MessageBox.Show("Por favor digite apenas numeros");
        }
    }
}
