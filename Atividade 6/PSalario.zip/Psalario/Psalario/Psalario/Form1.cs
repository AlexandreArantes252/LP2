﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Salario : Form
    {

        Double salarioBruto = 0;
        Double numFilhos = 0;
        Double salarioFamilia = 0;
        Double salarioLiquido = 0;
        Double aliquotaINSS = 0;
        Double aliquotaIRPF = 0;
        Double descontoINSS = 0;
        Double descontoIRPF = 0;
        string estadoCivil = "";
        string sexo = "";

        public Salario()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            
            //Validação do nome
            if (txtNomeFunc.Text == String.Empty)
                MessageBox.Show("O campo nome não pode estar vazio.");

            //Validação do salário bruto e converção numfilhos

            if (!Double.TryParse(mskbxSalBruto.Text, out salarioBruto) || (!Double.TryParse(NuDNumFilhos.Text, out numFilhos)))
                MessageBox.Show("O salário bruto deve receber um número.");
            else
            {
                if (salarioBruto <= 0)
                    MessageBox.Show("O salário deve ser maior do que zero.");
            }

            
            //alíquota INSS

            if (salarioBruto <= 800.47){ 
                descontoINSS = salarioBruto * 0.0765;
                txtAliquotaINSS.Text = "7,65%";
            }
            else if (salarioBruto <= 1050){
                descontoINSS = salarioBruto * 0.0865;
                txtAliquotaINSS.Text = "8,65%";
            }
            else if (salarioBruto <= 1400.77){
                descontoINSS = salarioBruto * 0.09;
                txtAliquotaINSS.Text = "9%";
            }
            else if (salarioBruto <= 2801.56){
                descontoINSS = salarioBruto * 0.11;
                txtAliquotaINSS.Text = "11%";
            }
            else {
                descontoINSS = 308.17;
                txtAliquotaINSS.Text = "Teto";
            }

            txtDescontoINSS.Text = descontoINSS.ToString("N2");

            //Aliquota IRPF

            if (salarioBruto <= 1257.12){
                descontoIRPF = 0;
                txtAliquotaIRPF.Text = "Isento";
            }
            else if (salarioBruto <= 2512.08){
                descontoIRPF = salarioBruto * 0.15;
                txtAliquotaIRPF.Text = "15%";
            }
            else{
                descontoIRPF = salarioBruto * 0.275;
                txtAliquotaIRPF.Text = "27,5%";
            }

            txtDescontoIRPF.Text = descontoIRPF.ToString("N2");

            //Salário família

            if (salarioBruto <= 435.52)
                salarioFamilia = 22.33 * numFilhos;

            else if (salarioBruto <= 654.61)
                salarioFamilia = 15.74 * numFilhos;

            else
                salarioFamilia = 0;

            txtSalFamilia.Text = salarioFamilia.ToString("N2");
           

            //Exibir salário líquido

            salarioLiquido = (salarioBruto - descontoINSS - descontoIRPF + salarioFamilia);

            txtSalLiquido.Text = salarioLiquido.ToString("N2");

            //Mensagem lblDdos.Text

            if (rbtnCasado.Checked)
                estadoCivil = "Casado(a)";
            else
                estadoCivil = "Solteiro(a)";

            if (rbtnMasc.Checked)
                sexo = "sr.";
            else
                sexo = "sra.";

            lblDados.Text = "O desconto do salário do " + sexo + txtNomeFunc.Text + " que é " +
                estadoCivil + " e que tem " + numFilhos + " filho(s) " + "é de R$:" + txtSalLiquido.Text;

           
        }
    } 
}
