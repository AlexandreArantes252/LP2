﻿namespace Psalario
{
    partial class Salario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblSalarioFam = new System.Windows.Forms.Label();
            this.lblSalarioLiq = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoIRPF = new System.Windows.Forms.TextBox();
            this.NuDNumFilhos = new System.Windows.Forms.NumericUpDown();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasc = new System.Windows.Forms.RadioButton();
            this.rbtnFem = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.rbtnCasado = new System.Windows.Forms.RadioButton();
            this.lblDados = new System.Windows.Forms.Label();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.NuDNumFilhos)).BeginInit();
            this.gbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFunc.Location = new System.Drawing.Point(153, 94);
            this.lblNomeFunc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(246, 25);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome do funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioBruto.Location = new System.Drawing.Point(153, 149);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(158, 25);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salário bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumFilhos.Location = new System.Drawing.Point(153, 202);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(204, 25);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaINSS.Location = new System.Drawing.Point(153, 438);
            this.lblAliquotaINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(162, 25);
            this.lblAliquotaINSS.TabIndex = 3;
            this.lblAliquotaINSS.Text = "Aíquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(153, 505);
            this.lblAliquotaIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(168, 25);
            this.lblAliquotaIRPF.TabIndex = 4;
            this.lblAliquotaIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalarioFam
            // 
            this.lblSalarioFam.AutoSize = true;
            this.lblSalarioFam.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFam.Location = new System.Drawing.Point(153, 569);
            this.lblSalarioFam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioFam.Name = "lblSalarioFam";
            this.lblSalarioFam.Size = new System.Drawing.Size(173, 25);
            this.lblSalarioFam.TabIndex = 5;
            this.lblSalarioFam.Text = "Salário família";
            // 
            // lblSalarioLiq
            // 
            this.lblSalarioLiq.AutoSize = true;
            this.lblSalarioLiq.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioLiq.Location = new System.Drawing.Point(153, 634);
            this.lblSalarioLiq.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioLiq.Name = "lblSalarioLiq";
            this.lblSalarioLiq.Size = new System.Drawing.Size(174, 25);
            this.lblSalarioLiq.TabIndex = 6;
            this.lblSalarioLiq.Text = "Salário líquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoINSS.Location = new System.Drawing.Point(687, 438);
            this.lblDescontoINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(180, 25);
            this.lblDescontoINSS.TabIndex = 7;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIRPF.Location = new System.Drawing.Point(687, 505);
            this.lblDescontoIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(179, 25);
            this.lblDescontoIRPF.TabIndex = 8;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(413, 360);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(261, 54);
            this.btnVerificar.TabIndex = 9;
            this.btnVerificar.Text = "Verificar desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(413, 91);
            this.txtNomeFunc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(260, 22);
            this.txtNomeFunc.TabIndex = 10;
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Location = new System.Drawing.Point(343, 436);
            this.txtAliquotaINSS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.ReadOnly = true;
            this.txtAliquotaINSS.Size = new System.Drawing.Size(260, 22);
            this.txtAliquotaINSS.TabIndex = 12;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(343, 502);
            this.txtAliquotaIRPF.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.ReadOnly = true;
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(260, 22);
            this.txtAliquotaIRPF.TabIndex = 13;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(343, 569);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(260, 22);
            this.txtSalFamilia.TabIndex = 14;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(343, 635);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(260, 22);
            this.txtSalLiquido.TabIndex = 15;
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Location = new System.Drawing.Point(901, 436);
            this.txtDescontoINSS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.ReadOnly = true;
            this.txtDescontoINSS.Size = new System.Drawing.Size(260, 22);
            this.txtDescontoINSS.TabIndex = 16;
            // 
            // txtDescontoIRPF
            // 
            this.txtDescontoIRPF.Location = new System.Drawing.Point(901, 506);
            this.txtDescontoIRPF.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescontoIRPF.Name = "txtDescontoIRPF";
            this.txtDescontoIRPF.ReadOnly = true;
            this.txtDescontoIRPF.Size = new System.Drawing.Size(260, 22);
            this.txtDescontoIRPF.TabIndex = 17;
            // 
            // NuDNumFilhos
            // 
            this.NuDNumFilhos.Location = new System.Drawing.Point(413, 202);
            this.NuDNumFilhos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.NuDNumFilhos.Name = "NuDNumFilhos";
            this.NuDNumFilhos.Size = new System.Drawing.Size(261, 22);
            this.NuDNumFilhos.TabIndex = 18;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasc);
            this.gbxSexo.Controls.Add(this.rbtnFem);
            this.gbxSexo.Location = new System.Drawing.Point(783, 91);
            this.gbxSexo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxSexo.Size = new System.Drawing.Size(264, 135);
            this.gbxSexo.TabIndex = 19;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnMasc
            // 
            this.rbtnMasc.AutoSize = true;
            this.rbtnMasc.Location = new System.Drawing.Point(24, 79);
            this.rbtnMasc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnMasc.Name = "rbtnMasc";
            this.rbtnMasc.Size = new System.Drawing.Size(92, 21);
            this.rbtnMasc.TabIndex = 1;
            this.rbtnMasc.Text = "Masculino";
            this.rbtnMasc.UseVisualStyleBackColor = true;
            // 
            // rbtnFem
            // 
            this.rbtnFem.AutoSize = true;
            this.rbtnFem.Checked = true;
            this.rbtnFem.Location = new System.Drawing.Point(24, 38);
            this.rbtnFem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnFem.Name = "rbtnFem";
            this.rbtnFem.Size = new System.Drawing.Size(86, 21);
            this.rbtnFem.TabIndex = 0;
            this.rbtnFem.TabStop = true;
            this.rbtnFem.Text = "Feminino";
            this.rbtnFem.UseVisualStyleBackColor = true;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.rbtnCasado);
            this.pnlCasado.Location = new System.Drawing.Point(783, 234);
            this.pnlCasado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(267, 55);
            this.pnlCasado.TabIndex = 2;
            // 
            // rbtnCasado
            // 
            this.rbtnCasado.AutoSize = true;
            this.rbtnCasado.Location = new System.Drawing.Point(24, 17);
            this.rbtnCasado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnCasado.Name = "rbtnCasado";
            this.rbtnCasado.Size = new System.Drawing.Size(95, 21);
            this.rbtnCasado.TabIndex = 0;
            this.rbtnCasado.Text = "Casado(a)";
            this.rbtnCasado.UseVisualStyleBackColor = true;
            this.rbtnCasado.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblDados.Location = new System.Drawing.Point(154, 308);
            this.lblDados.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(83, 20);
            this.lblDados.TabIndex = 20;
            this.lblDados.Text = "lblDados";
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(413, 146);
            this.mskbxSalBruto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskbxSalBruto.Mask = "99999.99";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(260, 22);
            this.mskbxSalBruto.TabIndex = 21;
            // 
            // Salario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Psalario.Properties.Resources.fundo_branco_abstrato_23_2148810353;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1235, 778);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.NuDNumFilhos);
            this.Controls.Add(this.txtDescontoIRPF);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioLiq);
            this.Controls.Add(this.lblSalarioFam);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Salario";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NuDNumFilhos)).EndInit();
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIRPF;
        private System.Windows.Forms.Label lblSalarioFam;
        private System.Windows.Forms.Label lblSalarioLiq;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtDescontoIRPF;
        private System.Windows.Forms.NumericUpDown NuDNumFilhos;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasc;
        private System.Windows.Forms.RadioButton rbtnFem;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.RadioButton rbtnCasado;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
    }
}

