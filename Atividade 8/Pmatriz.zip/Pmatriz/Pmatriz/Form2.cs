﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatriz
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            string[] nome = new string[200];
            int[] qtdCaracter = new int[200];
            string aux = "";

            for(int i = 0; i < nome.Length; i ++)
            {
                aux = Interaction.InputBox("Digite nome completo que queira consultar: ");

                if (aux == "")
                    break;

                if (aux != "")
                {
                    nome[i] = aux;
                    aux = nome[i].Replace(" ", "");
                    qtdCaracter[i] = aux.Length;

                    richTextBox1.Text = "O nome " + nome[i] + " tem " + qtdCaracter[i] +
                        " caracteres";
                }
                else
                {
                    MessageBox.Show("Preencha com um nome!");
                    i--; 
                }
            } 
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}


    