﻿
namespace Pmatriz
{
    partial class frm1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNumerosInverte = new System.Windows.Forms.Button();
            this.btnNumerosReverse = new System.Windows.Forms.Button();
            this.btnMercadoria = new System.Windows.Forms.Button();
            this.btnVariavelTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMediaAlunos = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNumerosInverte
            // 
            this.btnNumerosInverte.Location = new System.Drawing.Point(292, 196);
            this.btnNumerosInverte.Name = "btnNumerosInverte";
            this.btnNumerosInverte.Size = new System.Drawing.Size(149, 48);
            this.btnNumerosInverte.TabIndex = 0;
            this.btnNumerosInverte.Text = "Ler numeros e Inverter";
            this.btnNumerosInverte.UseVisualStyleBackColor = true;
            this.btnNumerosInverte.Click += new System.EventHandler(this.btnNumerosInverte_Click);
            // 
            // btnNumerosReverse
            // 
            this.btnNumerosReverse.Location = new System.Drawing.Point(447, 196);
            this.btnNumerosReverse.Name = "btnNumerosReverse";
            this.btnNumerosReverse.Size = new System.Drawing.Size(150, 48);
            this.btnNumerosReverse.TabIndex = 1;
            this.btnNumerosReverse.Text = "Ler Numeros e Inverte (Reverse)";
            this.btnNumerosReverse.UseVisualStyleBackColor = true;
            this.btnNumerosReverse.Click += new System.EventHandler(this.btnNumerosReverse_Click);
            // 
            // btnMercadoria
            // 
            this.btnMercadoria.Location = new System.Drawing.Point(603, 196);
            this.btnMercadoria.Name = "btnMercadoria";
            this.btnMercadoria.Size = new System.Drawing.Size(149, 48);
            this.btnMercadoria.TabIndex = 2;
            this.btnMercadoria.Text = "Ler a quantidade e o preço da mercadoria";
            this.btnMercadoria.UseVisualStyleBackColor = true;
            this.btnMercadoria.Click += new System.EventHandler(this.btnMercadoria_Click);
            // 
            // btnVariavelTotal
            // 
            this.btnVariavelTotal.Location = new System.Drawing.Point(303, 269);
            this.btnVariavelTotal.Name = "btnVariavelTotal";
            this.btnVariavelTotal.Size = new System.Drawing.Size(130, 41);
            this.btnVariavelTotal.TabIndex = 3;
            this.btnVariavelTotal.Text = "Variavel Total";
            this.btnVariavelTotal.UseVisualStyleBackColor = true;
            this.btnVariavelTotal.Click += new System.EventHandler(this.btnVariavelTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Location = new System.Drawing.Point(457, 269);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(130, 41);
            this.btnArrayList.TabIndex = 4;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMediaAlunos
            // 
            this.btnMediaAlunos.Location = new System.Drawing.Point(606, 269);
            this.btnMediaAlunos.Name = "btnMediaAlunos";
            this.btnMediaAlunos.Size = new System.Drawing.Size(130, 41);
            this.btnMediaAlunos.TabIndex = 5;
            this.btnMediaAlunos.Text = "Média Alunos";
            this.btnMediaAlunos.UseVisualStyleBackColor = true;
            this.btnMediaAlunos.Click += new System.EventHandler(this.btnMediaAlunos_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(457, 333);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 48);
            this.button1.TabIndex = 6;
            this.button1.Text = "Quantidade Caracter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pmatriz.Properties.Resources._2058777_fundo_branco_com_efeito_de_onda_gratis_vetor;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1055, 599);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnMediaAlunos);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnVariavelTotal);
            this.Controls.Add(this.btnMercadoria);
            this.Controls.Add(this.btnNumerosReverse);
            this.Controls.Add(this.btnNumerosInverte);
            this.Name = "frm1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNumerosInverte;
        private System.Windows.Forms.Button btnNumerosReverse;
        private System.Windows.Forms.Button btnMercadoria;
        private System.Windows.Forms.Button btnVariavelTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMediaAlunos;
        private System.Windows.Forms.Button button1;
    }
}

