﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatriz
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }

        private void btnNumerosInverte_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite um numero: " + (i + 1).ToString(),
                    "Entrada de Dados");

                if (aux == "")
                    break;


                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
            }

            aux = "";

            for (var i = 20 - 1; i >= 0; i--)
                aux += "\n" + vetor[i].ToString();

            MessageBox.Show(aux);

            /*Array.Reverse(vetor);
           auxiliar = "";
           foreach(int x in vetor)
           {
               auxiliar += x + "\n";
           }
           MessageBox.Show(auxiliar); */



            /*auxiliar = "";
            for(int i = 19; i>=0; i--)
            {
                auxiliar = auxiliar + "\n" + vetor[i];
            }
            MessageBox.Show(auxiliar); */
        }

        private void btnNumerosReverse_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite um numero: " + (i + 1).ToString(),
                    "Entrada de Dados");

                if (aux == "")
                    break;

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor invalido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            aux = "";

            for (int i = 20 - 1; i >= 0; i--)
            {
                aux += vetor[i].ToString() + "\n";
            }

            MessageBox.Show(aux);

        }

        private void btnMercadoria_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            string auxiliar = "";
            double faturamento = 0;

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria " + (i + 1),
                    "Entrada das quantidades");

                if (auxiliar == "")
                    break;

                if (!double.TryParse(auxiliar, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade inválida!");
                    i--;
                }
                else
                {
                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço da mercadoria " + (i + 1),
                    "Entrada dos preços");

                        if (!double.TryParse(auxiliar, out preco[i]))
                        {
                            MessageBox.Show("Proço Inválido");
                        }
                        else
                        {
                            if (preco[i] <= 0)
                            {
                                MessageBox.Show("Preço deve ser maior que zero");
                            }
                        }

                    }
                    faturamento += quantidade[i] * preco[i];
                }
            }
            MessageBox.Show("Faturamento:" + faturamento.ToString("N2"));
        }

        private void btnVariavelTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                    "Leonardo", "Jose", "Nelma", "Tobby"};

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N-1; I++)
            {
                Total += Alunos[I].Length;
                MessageBox.Show("O total vale: " + Total.ToString());
            }
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            ArrayList aarray = new ArrayList();

            aarray.Add("Ana");
            aarray.Add("André");
            aarray.Add("Débora");
            aarray.Add("Fátima");
            aarray.Add("João");
            aarray.Add("Janete");
            aarray.Add("Otávio");
            aarray.Add("Marcelo");
            aarray.Add("Pedro");
            aarray.Add("Thais");

            aarray.Remove("Otávio");

            string aux = "";

            for (int i = 0; i < aarray.Count; i++)
            {
                aux += aarray[i] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnMediaAlunos_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[20, 3];
            Double media = 0;
            string aux = "";
            string msg = "";
            

            for (int i = 0; i < 3; i++)
            {
                for (int a = 0; a < 3; a++)
                {
                    aux = Interaction.InputBox("Digite a nota "
                         + (a + 1).ToString() + " do aluno " + (i + 1).ToString());

                    if (aux == "")
                        break;

                    if (!(double.TryParse(aux, out nota[i, a])))
                    {
                        MessageBox.Show("Tipo de nota inválida!!");
                        a--;

                    }
                    else if (nota[i, a] < 0 || nota[i, a] > 10)
                    {
                        MessageBox.Show("Nota invalida!!");
                        a--;
                    }
                    else
                        media += nota[i, a];
                }
                
                
                media = media / 3;

                msg += "Aluno: " + (1 + i) + " tem a media: " +
                    media.ToString("N2") + "\n";
                media = 0;
            }
            MessageBox.Show(msg);


        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form Caracter = Application.OpenForms["frm2"];

            if (Caracter != null)
            {
                Caracter.Close();
            }

            Form2 frm1 = new Form2();
            frm1.WindowState = FormWindowState.Maximized;
            frm1.Show();
        }
    }
}

