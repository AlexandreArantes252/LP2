﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        Double Resultado, Numero1, Numero2;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            txtNumero1.Focus(); //Ganhara foco apos limpar dados, para um novo inicio
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
            {
                 Resultado = Numero1 * Numero2;
                 txtResultado.Text = Resultado.ToString("N2"); 
            }
            else
                MessageBox.Show("Por favor insira os dados!!");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
            {
                if (Numero1 == 0)
                    MessageBox.Show("Todo número dividido por zero é zero!!");

                if (Numero2 == 0)
                    MessageBox.Show("Não existe divisão por 0");

                if (Numero1 != 0 && Numero2 != 0)
                {
                    Resultado = Numero1 / Numero2;
                    txtResultado.Text = Resultado.ToString("N2");
                }

            }
            else
                MessageBox.Show("Por favor insira os dados!!");
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
            txtNumero1.Focus();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
            {
                 Resultado = Numero1 + Numero2;
                 txtResultado.Text = Resultado.ToString("N2");;
            }
            else
                MessageBox.Show("Por favor insira os dados!!");
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
            {
                   Resultado = Numero1 - Numero2;
                   txtResultado.Text = Resultado.ToString("N2");
            }
            else
                MessageBox.Show("Por favor insira os dados!!");
        }

    }

}
