﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double Peso, Altura, Imc;

        public Form1()
        {
            InitializeComponent();
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            mskAltura.Clear();
            mskPeso.Clear();

            mskPeso.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(mskPeso.Text, out Peso) && Double.TryParse(mskAltura.Text, out Altura)){

                if (Peso > 0 && Altura > 0)
                {
                    Imc = Peso/(Math.Pow(Altura, 2));
                    txtImc.Text = Imc.ToString();
               

                if (Imc < 18.5) 
                    MessageBox.Show("Sua classificação é: Magreza e Obesidade grau = 0");
                
                else if (Imc <= 24.9) 
                    MessageBox.Show("Sua classificação é: Normal e Obesidade grau = 0");
                
                else if (Imc <= 29.9) 
                    MessageBox.Show("Sua classificação é: Sobrepeso e Obesidade grau = I");
                
                else if (Imc  <= 39.9) 
                    MessageBox.Show("Sua classificação é: Obesidade e Obesidade grau = II");
                
                else 
                    MessageBox.Show("Sua classificação é: Obesidade Grave e Obesidade grau = III");

                }
                else
                {
                    MessageBox.Show("Digite seu peso e altura correta por favor");
                }

            }
        }
    }
}
