﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNum = new System.Windows.Forms.Button();
            this.btnPosBranco = new System.Windows.Forms.Button();
            this.btnAlfab = new System.Windows.Forms.Button();
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnNum
            // 
            this.btnNum.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNum.Location = new System.Drawing.Point(168, 306);
            this.btnNum.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(153, 50);
            this.btnNum.TabIndex = 0;
            this.btnNum.Text = "Númericos";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnPosBranco
            // 
            this.btnPosBranco.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosBranco.Location = new System.Drawing.Point(422, 306);
            this.btnPosBranco.Margin = new System.Windows.Forms.Padding(4);
            this.btnPosBranco.Name = "btnPosBranco";
            this.btnPosBranco.Size = new System.Drawing.Size(175, 50);
            this.btnPosBranco.TabIndex = 1;
            this.btnPosBranco.Text = "Posição primeiro espaço em branco";
            this.btnPosBranco.UseVisualStyleBackColor = true;
            this.btnPosBranco.Click += new System.EventHandler(this.btnPosBranco_Click);
            // 
            // btnAlfab
            // 
            this.btnAlfab.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlfab.Location = new System.Drawing.Point(694, 306);
            this.btnAlfab.Margin = new System.Windows.Forms.Padding(4);
            this.btnAlfab.Name = "btnAlfab";
            this.btnAlfab.Size = new System.Drawing.Size(161, 50);
            this.btnAlfab.TabIndex = 2;
            this.btnAlfab.Text = "Alfabéticos";
            this.btnAlfab.UseVisualStyleBackColor = true;
            this.btnAlfab.Click += new System.EventHandler(this.btnAlfab_Click);
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(168, 169);
            this.rchTxt.Margin = new System.Windows.Forms.Padding(4);
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(687, 117);
            this.rchTxt.TabIndex = 3;
            this.rchTxt.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PMetodos.Properties.Resources._2058777_fundo_branco_com_efeito_de_onda_gratis_vetor;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.rchTxt);
            this.Controls.Add(this.btnAlfab);
            this.Controls.Add(this.btnPosBranco);
            this.Controls.Add(this.btnNum);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnPosBranco;
        private System.Windows.Forms.Button btnAlfab;
        private System.Windows.Forms.RichTextBox rchTxt;
    }
}