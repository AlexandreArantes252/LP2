﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTesteClasses
{
    abstract class Empregado
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        public int Matricula
        {           //propriedade
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public Char HomeOffice
        {
            get { return homeOffice; }
            set { homeOffice = value; }
        }

        //metodos sao ações/comportamentos

        public String VerificaHome()
        {  //metodos
            if (homeOffice == 'S')
                return "Empregados Trabalha em Home Office";
            else
                return "Empregado Não trabalha em Home Office";
        }

        //virtual --> pode ser sobreescrito

        public virtual int TempoTrabalho()
        {
            //representa um intervalo e tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa); //subtração entre a data que entrou com a de hoje para identificar o tempo de trabalho
            return (span.Days);
        }

        //deve ser implementado nas classes filhas (subclasses)

        public abstract double SalarioBruto(); //Nao precisa implementar
    }
}
