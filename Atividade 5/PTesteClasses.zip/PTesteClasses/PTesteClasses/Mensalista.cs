﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTesteClasses
{
    class Mensalista : Empregado //especialização -> herança
    {
        public double SalarioMensal { get; set; }

        //sobreescrevendo o metodo

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        /* public Mensalista()
        {
            MessageBox.Show("passei por aqui"); 
        } por algum motivo não reconhce o message box */

        public Mensalista(Double x)
        {

        }

        public Mensalista(int matx, string nomex, DateTime datax, double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal =  salariox;

        }

    }
}

