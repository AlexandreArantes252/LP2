﻿namespace PTesteClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbntSim = new System.Windows.Forms.RadioButton();
            this.btnHorista = new System.Windows.Forms.Button();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.lblHoras = new System.Windows.Forms.Label();
            this.txtFalta = new System.Windows.Forms.TextBox();
            this.lblDiasdeFalta = new System.Windows.Forms.Label();
            this.gbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxHomeOffice
            // 
            this.gbxHomeOffice.Controls.Add(this.rbtnNao);
            this.gbxHomeOffice.Controls.Add(this.rbntSim);
            this.gbxHomeOffice.Location = new System.Drawing.Point(855, 129);
            this.gbxHomeOffice.Margin = new System.Windows.Forms.Padding(4);
            this.gbxHomeOffice.Name = "gbxHomeOffice";
            this.gbxHomeOffice.Padding = new System.Windows.Forms.Padding(4);
            this.gbxHomeOffice.Size = new System.Drawing.Size(267, 123);
            this.gbxHomeOffice.TabIndex = 33;
            this.gbxHomeOffice.TabStop = false;
            this.gbxHomeOffice.Text = "Trabalha em Home Office?";
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Checked = true;
            this.rbtnNao.Location = new System.Drawing.Point(16, 49);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(55, 21);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Nao";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbntSim
            // 
            this.rbntSim.AutoSize = true;
            this.rbntSim.Location = new System.Drawing.Point(16, 22);
            this.rbntSim.Name = "rbntSim";
            this.rbntSim.Size = new System.Drawing.Size(52, 21);
            this.rbntSim.TabIndex = 0;
            this.rbntSim.Text = "Sim";
            this.rbntSim.UseVisualStyleBackColor = true;
            // 
            // btnHorista
            // 
            this.btnHorista.Location = new System.Drawing.Point(926, 448);
            this.btnHorista.Margin = new System.Windows.Forms.Padding(4);
            this.btnHorista.Name = "btnHorista";
            this.btnHorista.Size = new System.Drawing.Size(201, 28);
            this.btnHorista.TabIndex = 31;
            this.btnHorista.Text = "Instanciar Horista";
            this.btnHorista.UseVisualStyleBackColor = true;
            this.btnHorista.Click += new System.EventHandler(this.btnHorista_Click);
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(342, 319);
            this.txtDataEntrada.Margin = new System.Windows.Forms.Padding(4);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(132, 22);
            this.txtDataEntrada.TabIndex = 30;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(342, 227);
            this.txtSalarioHora.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(132, 22);
            this.txtSalarioHora.TabIndex = 29;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(342, 172);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(433, 22);
            this.txtNome.TabIndex = 28;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(342, 125);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(132, 22);
            this.txtMatricula.TabIndex = 27;
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Location = new System.Drawing.Point(94, 328);
            this.lblDataEntrada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(195, 17);
            this.lblDataEntrada.TabIndex = 26;
            this.lblDataEntrada.Text = "Data de entrada na Empresa:";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(94, 236);
            this.lblSalarioHora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(116, 17);
            this.lblSalarioHora.TabIndex = 25;
            this.lblSalarioHora.Text = "Salario por Hora:";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(94, 181);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(49, 17);
            this.lblNome.TabIndex = 24;
            this.lblNome.Text = "Nome:";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(94, 129);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(69, 17);
            this.lblMatricula.TabIndex = 23;
            this.lblMatricula.Text = "Matricula:";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(342, 274);
            this.txtHora.Margin = new System.Windows.Forms.Padding(4);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(132, 22);
            this.txtHora.TabIndex = 35;
            // 
            // lblHoras
            // 
            this.lblHoras.AutoSize = true;
            this.lblHoras.Location = new System.Drawing.Point(94, 283);
            this.lblHoras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHoras.Name = "lblHoras";
            this.lblHoras.Size = new System.Drawing.Size(124, 17);
            this.lblHoras.TabIndex = 34;
            this.lblHoras.Text = "Numero de Horas:";
            // 
            // txtFalta
            // 
            this.txtFalta.Location = new System.Drawing.Point(342, 369);
            this.txtFalta.Margin = new System.Windows.Forms.Padding(4);
            this.txtFalta.Name = "txtFalta";
            this.txtFalta.Size = new System.Drawing.Size(132, 22);
            this.txtFalta.TabIndex = 37;
            // 
            // lblDiasdeFalta
            // 
            this.lblDiasdeFalta.AutoSize = true;
            this.lblDiasdeFalta.Location = new System.Drawing.Point(94, 378);
            this.lblDiasdeFalta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiasdeFalta.Name = "lblDiasdeFalta";
            this.lblDiasdeFalta.Size = new System.Drawing.Size(95, 17);
            this.lblDiasdeFalta.TabIndex = 36;
            this.lblDiasdeFalta.Text = "Dias de Falta:";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PTesteClasses.Properties.Resources.fundo_branco_abstrato_23_2148810353;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1220, 546);
            this.Controls.Add(this.txtFalta);
            this.Controls.Add(this.lblDiasdeFalta);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.lblHoras);
            this.Controls.Add(this.gbxHomeOffice);
            this.Controls.Add(this.btnHorista);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxHomeOffice.ResumeLayout(false);
            this.gbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxHomeOffice;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbntSim;
        private System.Windows.Forms.Button btnHorista;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label lblHoras;
        private System.Windows.Forms.TextBox txtFalta;
        private System.Windows.Forms.Label lblDiasdeFalta;
    }
}