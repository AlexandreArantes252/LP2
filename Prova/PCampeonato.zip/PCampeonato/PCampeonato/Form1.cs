﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[3, 3];
            string golsFeitos = "";
            string golsRecebidos = "";
            int saldoGol = 0;
            int aux = 0, totalGols = 0;

         

            for (int n = 0; n < 3; n++)
            {
                golsFeitos = "";
                golsRecebidos = "";


                for (int a = 0; a < 3; a++)
                {
                    golsFeitos = Interaction.InputBox("Insira os gols feitos do time " + (1 + a));

                    golsRecebidos = Interaction.InputBox("Insira os gols recebidos do time " + (1 + a));



                    if (golsFeitos == "" || golsRecebidos == "")
                        break;

                    if (!(int.TryParse(golsFeitos, out matriz[n, a]) || !(int.TryParse(golsRecebidos, out matriz[n, a]))))
                    {

                        MessageBox.Show("Tipo de valor inválido!!");
                        a--;

                    }
                    else if (matriz[n, a] < 0 || matriz[n, a] > 10)
                    {
                        MessageBox.Show("Valor inválido!!");
                        a--;
                    }

                    saldoGol = matriz[n, a];
                    aux = saldoGol - matriz[n, a];

                   

  

                }
                  


                listBox1.Items.Add("Time " + (1 + n));
                listBox1.Items.Add("Gols Feitos: " + golsFeitos.ToString());
                listBox1.Items.Add("Gols Recebidos: " + golsRecebidos.ToString());
                listBox1.Items.Add("Saldos de gol: " + saldoGol.ToString());
                listBox1.Items.Add("\n");



            }


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}

